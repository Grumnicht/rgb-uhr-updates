/*
 * RGB-Uhr LED-Editor fuer Home Assistant (ohne externe Abhaengigkeiten).
 * Datei nach /config/www/rgb_uhr_editor.js kopieren.
 * Dashboard Ressource: /local/rgb_uhr_editor.js (JavaScript-Modul)
 * Karte: type: custom:rgb-uhr-editor-card
 */
class RgbUhrEditorCard extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this._bereich = 'd4';
    this._index = 0;
    this._farbe = '#ff9900';
    this._rendered = false;
  }

  setConfig(config) { this.config = config || {}; }
  getCardSize() { return 7; }

  set hass(hass) {
    this._hass = hass;
    if (!this._rendered) this._init();
    this._refresh();
  }

  _counts() { return { d4: 36, d5: 32, d6: 25, d7: 19 }; }
  _get(id) { return this._hass?.states[id]?.state ?? ''; }
  _frame(id) {
    const size = this._counts()[id];
    const manual = this._get(`input_boolean.rgb_uhr_manuell_${id}`) === 'on';
    const data = this._get(`${manual ? 'input_text.rgb_uhr_frame_manuell_' : 'sensor.rgb_uhr_led_'}${id}`);
    const raw = manual ? data : (data.startsWith('@') ? data.slice(1) : '');
    return (raw.length === size * 6 && /^[0-9a-fA-F]+$/.test(raw))
      ? raw.toUpperCase() : '000000'.repeat(size);
  }

  _init() {
    this.shadowRoot.innerHTML = `
      <style>
        :host { display:block; font:inherit; }
        ha-card { display:block; padding:16px; }
        h3 {margin:0 0 8px;font-size:18px}
        p {margin:6px 0 12px;opacity:.76;font-size:13px}
        .top {display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:12px 0}
        select, input[type="color"], button {font:inherit;min-height:40px;border-radius:9px;border:1px solid var(--divider-color,#999);background:var(--card-background-color,#fff);color:var(--primary-text-color,#222)}
        select {padding:0 8px;flex:1;min-width:145px}
        input[type="color"] {width:62px;padding:3px;cursor:pointer}
        button {padding:6px 10px;cursor:pointer}
        button:focus-visible {outline:2px solid var(--primary-color,#03a9f4)}
        .actions {display:flex;flex-wrap:wrap;gap:7px;margin:10px 0}
        .pixels {display:grid;grid-template-columns:repeat(auto-fit,minmax(43px,1fr));gap:6px;margin:12px 0}
        .pixel {position:relative;aspect-ratio:1.12;min-height:43px;display:flex;align-items:center;justify-content:center;cursor:pointer;border:2px solid transparent;border-radius:8px;background:var(--secondary-background-color,#eee);font-weight:600;font-size:12px}
        .pixel.selected {border-color:var(--primary-color,#03a9f4)}
        .dot {width:16px;height:16px;border-radius:50%;display:block;margin-right:5px;border:1px solid #777;box-shadow:0 0 7px rgba(0,0,0,.16)}
        .meta {font-size:12px;opacity:.75}
        .status {margin:8px 0;min-height:21px;font-size:13px}
        @media(max-width:500px){.pixels{grid-template-columns:repeat(7,minmax(0,1fr))}.pixel{font-size:10px;min-height:40px;padding:0}}
      </style>
      <ha-card>
        <h3>Einzelne RGB-LEDs bearbeiten</h3>
        <p>112 LEDs, einzeln steuerbar. Nach dem Bearbeiten per „Automatik“ zur normalen Uhr zurueckkehren.</p>
        <div class="top">
          <select id="bereich" aria-label="LED-Kette">
            <option value="d4">D4 · Stunden (36)</option>
            <option value="d5">D5 · Minuten (32)</option>
            <option value="d6">D6 · Datum (25)</option>
            <option value="d7">D7 · Temperatur (19)</option>
          </select>
          <input id="farbe" type="color" aria-label="LED-Farbe" value="#ff9900" />
          <span class="meta" id="auswahl">LED 0</span>
        </div>
        <div class="actions">
          <button id="set">LED faerben</button>
          <button id="off">LED aus</button>
          <button id="clear">Alle aus</button>
          <button id="auto">Automatik</button>
        </div>
        <div id="status" class="status"></div>
        <div id="pixels" class="pixels"></div>
        <p>Die Farbauswahl wird als RGB-Bild in Home Assistant gespeichert, nicht im Wemos programmiert. Im Einzelmodus beeinflusst die Gesamthelligkeit die manuell gesetzten RGB-Werte nicht.</p>
      </ha-card>
    `;
    const el = id => this.shadowRoot.getElementById(id);
    el('bereich').addEventListener('change', e => { this._bereich = e.target.value; this._index = 0; this._drawPixels(); });
    el('farbe').addEventListener('input', e => { this._farbe = e.target.value; });
    el('set').addEventListener('click', () => this._setPixel(this._farbe));
    el('off').addEventListener('click', () => this._setPixel('#000000'));
    el('clear').addEventListener('click', () => this._replace('000000'.repeat(this._counts()[this._bereich])));
    el('auto').addEventListener('click', () => this._call('input_boolean','turn_off',{entity_id:`input_boolean.rgb_uhr_manuell_${this._bereich}`}));
    this._rendered = true;
    this._drawPixels();
  }

  _refresh() { if (this._rendered) this._drawPixels(); }
  _drawPixels() {
    const grid = this.shadowRoot.getElementById('pixels');
    const size = this._counts()[this._bereich];
    const frame = this._frame(this._bereich);
    const status = this.shadowRoot.getElementById('status');
    const manual = this._get(`input_boolean.rgb_uhr_manuell_${this._bereich}`) === 'on';
    status.textContent = `${manual ? 'Einzelsteuerung aktiv' : 'Automatik aktiv'} · ${this._bereich.toUpperCase()}`;
    this.shadowRoot.getElementById('auswahl').textContent = `LED ${this._index}`;
    if (grid.children.length !== size || grid.dataset.chain !== this._bereich) {
      grid.replaceChildren();
      grid.dataset.chain = this._bereich;
      for (let i = 0; i < size; i++) {
        const btn = document.createElement('button');
        btn.className = 'pixel';
        btn.type = 'button';
        btn.setAttribute('aria-label', `LED ${i} auswaehlen`);
        btn.innerHTML = `<span class="dot"></span><span>${i}</span>`;
        btn.addEventListener('click', () => { this._index = i; this._drawPixels(); });
        grid.appendChild(btn);
      }
    }
    for (let i = 0; i < size; i++) {
      const btn = grid.children[i];
      btn.classList.toggle('selected',i===this._index);
      btn.querySelector('.dot').style.backgroundColor = `#${frame.slice(i*6,i*6+6)}`;
    }
  }

  async _setPixel(hex) {
    const f = this._frame(this._bereich);
    const color = hex.replace('#','').toUpperCase();
    const at = this._index * 6;
    await this._replace(f.slice(0,at) + color + f.slice(at+6));
  }

  async _replace(frame) {
    const id=this._bereich;
    try {
      await this._call('input_text','set_value',{entity_id:`input_text.rgb_uhr_frame_manuell_${id}`,value:frame});
      await this._call('input_boolean','turn_on',{entity_id:`input_boolean.rgb_uhr_manuell_${id}`});
    } catch(e) { this._message(`Fehler: ${e.message}`); }
  }

  async _call(domain, service, data) {
    if (!this._hass) return;
    try { await this._hass.callService(domain,service,data); }
    catch(e) { this._message(`Home Assistant: ${e.message}`); throw e; }
  }
  _message(msg) { this.shadowRoot.getElementById('status').textContent=msg; }
}
customElements.define('rgb-uhr-editor-card', RgbUhrEditorCard);
window.customCards = window.customCards || [];
window.customCards.push({type:'rgb-uhr-editor-card',name:'RGB Wanduhr LED-Editor',description:'Einzelne LED-Farben direkt in Home Assistant setzen'});
